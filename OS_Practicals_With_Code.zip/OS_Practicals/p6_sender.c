#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

int main()
{
    char text[4096];
    char result[200];
    int fd, n;
    int used = 0;

    printf("Enter sentences. Type END on a new line to finish:\n");

    while (fgets(text + used, sizeof(text) - used, stdin) != NULL)
    {
        if (strcmp(text + used, "END\n") == 0 ||
            strcmp(text + used, "END") == 0)
        {
            text[used] = '\0';
            break;
        }

        used += strlen(text + used);

        if (used >= sizeof(text) - 2)
            break;
    }

    fd = open("fifo1", O_WRONLY);
    write(fd, text, used);
    close(fd);

    fd = open("fifo2", O_RDONLY);

    printf("\nResult from receiver:\n");

    while ((n = read(fd, result, sizeof(result) - 1)) > 0)
    {
        result[n] = '\0';
        printf("%s", result);
    }

    close(fd);

    return 0;
}
