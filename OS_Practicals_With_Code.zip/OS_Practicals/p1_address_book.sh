#!/bin/bash

file="address.txt"

while true
do
    echo
    echo "----- ADDRESS BOOK -----"
    echo "1. Create"
    echo "2. View"
    echo "3. Insert"
    echo "4. Delete"
    echo "5. Modify"
    echo "6. Exit"

    read -p "Enter choice: " ch

    case $ch in
        1)
            > "$file"
            echo "Address book created"
            ;;

        2)
            if [ -f "$file" ]; then
                cat "$file"
            else
                echo "First create the address book"
            fi
            ;;

        3)
            read -p "Enter ID: " id
            read -p "Enter name: " name
            read -p "Enter phone: " phone
            echo "$id $name $phone" >> "$file"
            echo "Record inserted"
            ;;

        4)
            read -p "Enter ID to delete: " id
            if [ -f "$file" ] && grep -q "^$id " "$file"; then
                grep -v "^$id " "$file" > temp.txt
                mv temp.txt "$file"
                echo "Record deleted"
            else
                echo "Record not found"
            fi
            ;;

        5)
            read -p "Enter ID to modify: " id
            if [ -f "$file" ] && grep -q "^$id " "$file"; then
                read -p "Enter new name: " name
                read -p "Enter new phone: " phone
                grep -v "^$id " "$file" > temp.txt
                echo "$id $name $phone" >> temp.txt
                mv temp.txt "$file"
                echo "Record modified"
            else
                echo "Record not found"
            fi
            ;;

        6)
            echo "Exiting"
            exit
            ;;

        *)
            echo "Wrong choice"
            ;;
    esac
done
