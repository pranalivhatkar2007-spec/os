# Operating Systems Practicals

Simple Ubuntu programs for the three practicals:

1. Shell Programming - Address Book
2. Thread Synchronization - Dining Philosophers
3. Interprocess Communication - FIFO

The programs are kept simple and use basic commands and functions.

## Requirements

Open Ubuntu Terminal and install the C compiler:

```bash
sudo apt update
sudo apt install build-essential
```

## Practical 1: Address Book

Open the folder in Terminal and run:

```bash
chmod +x p1_address_book.sh
./p1_address_book.sh
```

Choose:
- 1 to create the address book
- 2 to view records
- 3 to insert a record
- 4 to delete a record by ID
- 5 to modify a record by ID
- 6 to exit

The records are saved in `address.txt`.

## Practical 4: Dining Philosophers

Compile:

```bash
gcc p4_dining_philosophers.c -o dining -pthread
```

Run:

```bash
./dining
```

Five threads represent five philosophers. Each philosopher takes two forks, eats, and puts the forks back. The `room` semaphore allows at most four philosophers to compete for forks at once, which prevents deadlock.

## Practical 6: FIFO Communication

Compile both programs:

```bash
gcc p6_receiver.c -o receiver
gcc p6_sender.c -o sender
```

Open two Terminal windows in this same folder.

**Terminal 1:**

```bash
./receiver
```

**Terminal 2:**

```bash
./sender
```

Type one or more lines. Type `END` on a separate line when finished.

The receiver counts characters, words and lines, saves the result in `result.txt`, and sends the result back to the sender.

Run the receiver first every time. Both programs must run from the same folder.

## Files

- `p1_address_book.sh` - Practical 1
- `p4_dining_philosophers.c` - Practical 4
- `p6_sender.c` - Practical 6 sender
- `p6_receiver.c` - Practical 6 receiver
