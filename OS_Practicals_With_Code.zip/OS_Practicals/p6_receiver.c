#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <ctype.h>

int main()
{
    char text[4096];
    int fd, n, i;
    int words = 0, lines = 0, inword = 0;

    mkfifo("fifo1", 0666);
    mkfifo("fifo2", 0666);

    printf("Receiver is waiting...\n");

    fd = open("fifo1", O_RDONLY);
    n = read(fd, text, sizeof(text) - 1);
    close(fd);

    if (n <= 0)
    {
        printf("No data received\n");
        return 1;
    }

    text[n] = '\0';

    for (i = 0; i < n; i++)
    {
        if (text[i] == '\n')
            lines++;

        if (isspace((unsigned char)text[i]))
            inword = 0;
        else if (inword == 0)
        {
            words++;
            inword = 1;
        }
    }

    if (n > 0 && text[n - 1] != '\n')
        lines++;

    FILE *fp = fopen("result.txt", "w");

    if (fp == NULL)
    {
        perror("result.txt");
        return 1;
    }

    fprintf(fp, "Characters = %d\n", n);
    fprintf(fp, "Words = %d\n", words);
    fprintf(fp, "Lines = %d\n", lines);
    fclose(fp);

    fp = fopen("result.txt", "r");

    if (fp == NULL)
    {
        perror("result.txt");
        return 1;
    }

    fd = open("fifo2", O_WRONLY);

    while ((n = fread(text, 1, sizeof(text), fp)) > 0)
        write(fd, text, n);

    close(fd);
    fclose(fp);

    printf("Result sent to sender\n");

    return 0;
}
